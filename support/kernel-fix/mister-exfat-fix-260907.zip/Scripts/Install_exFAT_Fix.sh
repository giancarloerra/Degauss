#!/bin/bash

set -uo pipefail
script_dir=$(CDPATH= cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd -P) || exit 1
printf 'Optional MiSTer exFAT kernel fix\n'
/bin/bash "$script_dir/.degauss-exfat-fix/kernel-fix.sh" install
result=$?
if [[ -t 0 ]]; then
    printf '\nPress Enter to return to the Scripts menu. '
    read -r reply || :
fi
exit "$result"
