#!/bin/bash

set -Eeuo pipefail
export PATH=/usr/bin:/bin:/usr/sbin:/sbin
export LC_ALL=C
umask 022

readonly MISTER_FAT='/media/fat'
readonly RELEASE_FILE='/MiSTer.version'
readonly MOUNTS_FILE='/proc/mounts'
readonly LOCK_FILE='/tmp/degauss-exfat-kernel.lock'
readonly EXPECTED_RELEASE='6.18.38-MiSTer'
readonly EXPECTED_MARKER='260907'
readonly EXPECTED_ARCH='armv7l'
readonly STOCK_BUILD='#1 SMP Mon Sep  7 17:23:26 CST 2026'
readonly PATCHED_BUILD='#103 SMP Tue Sep  8 20:30:09 UTC 2026'
readonly STOCK_SHA='0bec449e365e757d14711bead76c5b1805d2b613a39e633fe7dc9f08e5687e73'
readonly PATCHED_SHA='b350283e0aa306cc24ef2a2e8213cd11ae1345054059239cb1516a81f9d5c706'
readonly KERNEL_DIR="$MISTER_FAT/linux"
readonly KERNEL="$KERNEL_DIR/zImage_dtb"
readonly BACKUP="$KERNEL_DIR/degauss-exfat-original-260907.zImage_dtb"
readonly PACKAGE_DIR="$MISTER_FAT/Scripts/.degauss-exfat-fix"
readonly PAYLOAD="$PACKAGE_DIR/zImage_dtb"
STAGE=''
REPLACED=0
REPLACEMENT_ATTEMPTED=0

fail() {
    printf '\nERROR: %s\n' "$*" >&2
    if (( REPLACED )); then
        printf 'The kernel replacement already occurred. Do not reboot until its integrity is checked. The original backup has not been overwritten.\n' >&2
    elif (( REPLACEMENT_ATTEMPTED )); then
        printf 'Kernel replacement was attempted and its outcome is not verified. Do not reboot until the kernel file is checked. The original backup has not been overwritten.\n' >&2
    fi
    exit 1
}

cleanup() {
    local result=$?
    trap - EXIT
    if [[ -n "$STAGE" ]]; then
        case "$STAGE" in
            "$KERNEL_DIR"/.degauss-exfat-stage.*)
                if ! rm -f "$STAGE"; then
                    printf 'ERROR: Could not remove temporary stage %s\n' "$STAGE" >&2
                    result=1
                fi
                ;;
            *) printf 'ERROR: Refusing unexpected temporary path.\n' >&2; result=1 ;;
        esac
    fi
    exit "$result"
}

trap cleanup EXIT
trap 'fail "Command failed at line $LINENO (status $?)."' ERR
trap 'fail "Interrupted. Check the messages above before rebooting."' INT TERM HUP

plain_file() {
    [[ -f "$1" && ! -L "$1" ]] || fail "Expected a regular, non-linked file: $1"
}

hash_file() {
    local output
    output=$(sha256sum "$1") || fail "Could not hash $1"
    printf '%s' "${output%% *}"
}

expect_hash() {
    local actual
    plain_file "$1"
    actual=$(hash_file "$1")
    [[ "$actual" == "$2" ]] || fail "Checksum mismatch for $1. Expected $2; found $actual."
}

preflight() {
    local tool build marker mounted=0 device mount_point filesystem flags rest
    for tool in id uname sha256sum flock mktemp df awk wc cat dd mv rm sync dirname; do
        command -v "$tool" >/dev/null || fail "Required command is unavailable: $tool"
    done
    [[ $(id -u) == 0 ]] || fail 'Run this from the MiSTer Scripts menu as root.'
    [[ $(uname -m) == "$EXPECTED_ARCH" ]] || fail 'This package only recognises the tested ARM MiSTer installation.'
    [[ $(uname -r) == "$EXPECTED_RELEASE" ]] || fail 'The running Linux release is not supported by this package.'
    build=$(uname -v)
    [[ "$build" == "$STOCK_BUILD" || "$build" == "$PATCHED_BUILD" ]] || fail 'The running kernel build is not recognised. No replacement is permitted.'
    plain_file "$RELEASE_FILE"
    marker=$(cat "$RELEASE_FILE")
    [[ "$marker" == "$EXPECTED_MARKER" ]] || fail 'This package only supports Linux distribution 260907. Do not use it after a Linux update.'
    [[ -d "$MISTER_FAT" && ! -L "$MISTER_FAT" && -d "$KERNEL_DIR" && ! -L "$KERNEL_DIR" ]] || fail 'The SD-card kernel directory is missing or linked elsewhere.'
    [[ -d "$PACKAGE_DIR" && ! -L "$PACKAGE_DIR" ]] || fail 'Copy the package Scripts folder to the root of the SD card.'
    [[ $(CDPATH= cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd -P) == "$PACKAGE_DIR" ]] || fail 'The helper is not in its required package directory.'
    while read -r device mount_point filesystem flags rest; do
        if [[ "$mount_point" == "$MISTER_FAT" ]]; then
            (( mounted += 1 ))
            [[ "$filesystem" == exfat || "$filesystem" == vfat ]] || fail 'The kernel directory must be on the directly mounted FAT/exFAT SD partition.'
            [[ ",$flags," == *,rw,* ]] || fail 'The SD partition is mounted read-only.'
        fi
    done < "$MOUNTS_FILE"
    (( mounted == 1 )) || fail 'The SD-card mount is not uniquely identified.'
    plain_file "$KERNEL"
    [[ ! -L "$LOCK_FILE" ]] || fail 'The installer lock path is linked elsewhere.'
    exec 9>>"$LOCK_FILE"
    flock -n 9 || fail 'Another kernel install/restore operation is running.'
}

check_backup() {
    if [[ -e "$BACKUP" || -L "$BACKUP" ]]; then
        expect_hash "$BACKUP" "$STOCK_SHA"
        return 0
    fi
    return 1
}

require_space() {
    local source=$1 extra=$2 available bytes needed
    bytes=$(wc -c < "$source")
    available=$(df -Pk "$KERNEL_DIR" | awk 'NR == 2 { print $4 }')
    [[ "$available" =~ ^[0-9]+$ ]] || fail 'Could not determine available space on the SD partition.'
    needed=$(( (bytes + extra + 1023) / 1024 + 4096 ))
    (( available >= needed )) || fail "Not enough free space: need at least ${needed} KiB; found ${available} KiB."
}

confirm() {
    local reply
    printf '\n%s\n' "$1"
    printf 'Keep power on. Do not run Update All/Downloader at the same time.\n'
    printf 'Continue? [y/N] '
    if ! read -r reply; then
        printf '\nCancelled. The kernel has not changed.\n'
        return 1
    fi
    case "$reply" in y|Y|yes|YES|Yes) return 0 ;; esac
    printf 'Cancelled. The kernel has not changed.\n'
    return 1
}

replace_kernel() {
    local source=$1 source_sha=$2 current_sha=$3
    STAGE=$(mktemp "$KERNEL_DIR/.degauss-exfat-stage.XXXXXX") || fail 'Could not create a staging file beside the kernel.'
    dd if="$source" of="$STAGE" bs=1M conv=fsync status=none || fail 'Could not copy and flush the replacement staging file.'
    expect_hash "$STAGE" "$source_sha"
    sync -f "$KERNEL_DIR" || fail 'Could not flush the kernel filesystem before replacement. The live kernel is unchanged.'
    expect_hash "$KERNEL" "$current_sha"
    REPLACEMENT_ATTEMPTED=1
    mv -f "$STAGE" "$KERNEL" || fail 'Could not replace the kernel. The original backup is retained.'
    STAGE=''
    REPLACED=1
    sync -f "$KERNEL_DIR" || fail 'Could not flush the kernel filesystem after replacement.'
    expect_hash "$KERNEL" "$source_sha"
    printf '\nVerified replacement complete. Reboot MiSTer when ready.\n'
    printf 'Original backup retained: %s\n' "$BACKUP"
}

main() {
    local mode=${1:-} current has_backup=0 backup_bytes=0
    [[ "$mode" == install || "$mode" == restore || "$mode" == check ]] || fail 'Expected install, restore or check.'
    preflight
    current=$(hash_file "$KERNEL")
    [[ "$current" == "$STOCK_SHA" || "$current" == "$PATCHED_SHA" ]] || fail 'The installed kernel is unknown, newer or modified. Nothing will be replaced.'
    if check_backup; then has_backup=1; fi
    if [[ "$mode" == check ]]; then
        printf 'Supported installation. Kernel: %s\nVerified original backup present: %s\n' "$current" "$has_backup"
        return
    fi
    if [[ "$mode" == install ]]; then
        expect_hash "$PAYLOAD" "$PATCHED_SHA"
        if [[ "$current" == "$PATCHED_SHA" ]]; then
            printf 'This exact exFAT fix is already installed. No files changed.\n'
            if (( ! has_backup )); then
                printf 'WARNING: This package has no verified original backup. Its restore script cannot restore the original kernel until that backup exists.\n'
            fi
            return
        fi
        if (( ! has_backup )); then backup_bytes=$(wc -c < "$KERNEL"); fi
        require_space "$PAYLOAD" "$backup_bytes"
        confirm 'Install the optional exFAT fix for the recognised 260907 Linux release?' || return 0
        expect_hash "$KERNEL" "$STOCK_SHA"
        if (( ! has_backup )); then
            (set -o noclobber; dd if="$KERNEL" bs=1M conv=fsync status=none > "$BACKUP") || fail 'Could not create and flush the original backup without overwriting a file. The live kernel is unchanged.'
            expect_hash "$BACKUP" "$STOCK_SHA"
            sync -f "$KERNEL_DIR" || fail 'Could not flush the original backup directory entry. The live kernel is unchanged.'
        fi
        expect_hash "$BACKUP" "$STOCK_SHA"
        replace_kernel "$PAYLOAD" "$PATCHED_SHA" "$STOCK_SHA"
    else
        if [[ "$current" == "$STOCK_SHA" ]]; then
            printf 'The recognised original kernel is already installed. No files changed.\n'
            return
        fi
        (( has_backup )) || fail 'The verified original backup is missing. Use the README recovery instructions; no file has been replaced.'
        require_space "$BACKUP" 0
        confirm 'Restore the recognised original 260907 Linux kernel? This removes the optional exFAT fix.' || return 0
        expect_hash "$BACKUP" "$STOCK_SHA"
        replace_kernel "$BACKUP" "$STOCK_SHA" "$PATCHED_SHA"
    fi
}

main "$@"
